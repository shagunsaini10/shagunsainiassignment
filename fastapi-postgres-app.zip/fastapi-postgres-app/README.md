# FastAPI + PostgreSQL — Dockerized with IPvlan Networking

> Project Assignment 1 — Containerized Web Application with Docker Compose and IPvlan

## Stack
- **Backend:** FastAPI (Python 3.11 Alpine) — multi-stage build
- **Database:** PostgreSQL 15 Alpine — named volume persistence
- **Network:** IPvlan L2 with static IPs + internal bridge
- **Orchestration:** Docker Compose with healthchecks

## Quick Start

### 1. Create IPvlan network
```bash
docker network create \
  -d ipvlan \
  --subnet=172.29.80.0/20 \
  --gateway=172.29.80.1 \
  -o ipvlan_mode=l2 \
  -o parent=eth0 \
  ipvlan_net
```

### 2. Start the stack
```bash
docker compose up --build -d
```

### 3. Test the API
```bash
curl http://localhost:8000/health
curl -X POST http://localhost:8000/records -H "Content-Type: application/json" -d '{"name":"test","value":"hello"}'
curl http://localhost:8000/records
```

## Endpoints

| Method | URL | Description |
|--------|-----|-------------|
| GET | `/health` | Healthcheck |
| POST | `/records` | Insert record |
| GET | `/records` | Fetch all records |

## Container IPs

| Container | IPvlan IP |
|-----------|-----------|
| fastapi_backend | 172.29.80.10 |
| postgres_db | 172.29.80.11 |

## Project Structure
```
├── backend/
│   ├── Dockerfile        # Multi-stage Alpine build
│   ├── main.py           # FastAPI app
│   ├── requirements.txt
│   └── .dockerignore
├── database/
│   ├── Dockerfile        # postgres:15-alpine
│   └── .dockerignore
├── docker-compose.yml
├── .env
└── REPORT.md
```

## Report
See [REPORT.md](./REPORT.md) for full writeup including:
- Build optimization explanation
- Network design diagram
- Image size comparison
- Macvlan vs IPvlan comparison
